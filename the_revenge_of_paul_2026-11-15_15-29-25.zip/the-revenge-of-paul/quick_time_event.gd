extends Node2D

@onready var Bar: Sprite2D = $Bar
@onready var Pointer: Sprite2D = $Pointer
@onready var start: Marker2D = $start
@onready var end: Marker2D = $end
@onready var safestartpos: Marker2D = $safestartpos
@onready var safeendpos: Marker2D  = $safeendpos
@onready var enemy: CharacterBody2D = $".../enemy"

var direction = 1


func _process(delta: float) -> void:
	
	if Pointer.position.x <= start.position.x:
		direction = 1
	elif Pointer.position.x >= end.position.x:
		direction = -1
		
	Pointer.position.x += direction
	
	if Input.is_action_pressed("ui_accept"):
		if Pointer.position.x >= safestartpos.position.x and Pointer.position.x <= safeendpos.position.x:
			enemy.hurt()
	
